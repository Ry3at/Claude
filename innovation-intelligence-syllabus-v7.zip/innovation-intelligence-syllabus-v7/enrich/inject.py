# -*- coding: utf-8 -*-
"""تزریق لایه‌ی «راهنمای تدریس» به بدنه‌ی سیلابس پایه‌های ۵ و ۶.

دو بلوک تازه به هر جلسه اضافه می‌شود:
  * جعبه‌ی «پیش از تدریس بخوانید»  → بعد از \\payvand، پیش از \\begin{masir}
  * جعبه‌ی «راهنمای اجرا برای معلم» → بعد از جعبه‌ی dastgah، پیش از \\khorooji
  * \\pol{...}                      → بعد از \\nokte

از فایل مبدأ (_v5_body5.tex / _v5_body6.tex) می‌خواند و نسخه‌ی غنی‌شده را
در همان‌جا می‌نویسد. برای اجرای دوباره، از نسخه‌ی پشتیبان .orig استفاده می‌کند.

**همه‌ی جای‌گذاری‌ها با شمارش آکولاد انجام می‌شود، نه regex ساده** — درس
گرفته‌شده از خرابی \\mavad در بازنگری‌های قبل.
"""
import io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

FA = '۰۱۲۳۴۵۶۷۸۹'


def fa(n):
    return ''.join(FA[int(c)] if c.isdigit() else c for c in str(n))


def macro_end(s, start):
    """پایان یک ماکرو با آرگومان آکولادی، با شمارش آکولاد.

    start باید روی نخستین '{' بعد از نام ماکرو باشد.
    """
    depth = 0
    i = start
    while i < len(s):
        if s[i] == '{':
            depth += 1
        elif s[i] == '}':
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    raise ValueError('unbalanced braces from %d' % start)


def end_of_macro_call(s, name, frm=0, nargs=1):
    """انتهای فراخوانی \\name{..}{..} را برمی‌گرداند (یا None)."""
    m = re.search(r'\\' + name + r'\s*\{', s[frm:])
    if not m:
        return None
    pos = frm + m.end() - 1
    for _ in range(nargs):
        pos = macro_end(s, pos)
        nxt = re.match(r'\s*\{', s[pos:])
        if nxt:
            pos = pos + nxt.end() - 1
        else:
            break
    return pos


def esc_tex(t):
    """کاراکترهای خطرناک لاتک را که نویسنده خام گذاشته، امن می‌کند.

    ماکروهای مجاز (\\software{} \\sq{} \\en{} \\textbf{}) دست‌نخورده می‌مانند.
    """
    out = []
    i = 0
    while i < len(t):
        c = t[i]
        if c == '\\':
            m = re.match(r'\\[a-zA-Z]+', t[i:])
            if m:
                out.append(m.group(0))
                i += m.end()
                continue
            out.append('\\textbackslash{}')
            i += 1
            continue
        if c in '%&#$':
            out.append('\\' + c)
        elif c == '~':
            out.append('\\textasciitilde{}')
        elif c == '^':
            out.append('\\textasciicircum{}')
        elif c == '_':
            out.append('\\_')
        else:
            out.append(c)
        i += 1
    return ''.join(out)


def build_mafhoom(d):
    o = ['\\begin{mafhoom}\n']
    o.append('\\mfh{%s}\n' % esc_tex(d['mafhoom']))
    o.append('\\mfchera{%s}\n' % esc_tex(d['chera']))
    o.append('\\end{mafhoom}\n')
    return ''.join(o)


def build_tadris(d):
    o = ['\\begin{tadris}\n']
    for err, react in d['khata']:
        o.append('\\khata{%s}{%s}\n' % (esc_tex(err), esc_tex(react)))
    fast, slow = d['tafavot']
    o.append('\\tafavot{%s}{%s}\n' % (esc_tex(fast), esc_tex(slow)))
    o.append('\\meyar{%s}\n' % esc_tex(d['meyar']))
    o.append('\\poshtiban{%s}\n' % esc_tex(d['poshtiban']))
    o.append('\\end{tadris}\n')
    return ''.join(o)


def enrich_block(block, d):
    """یک بلوک \\begin{jalase}...\\end{jalase} را غنی می‌کند."""
    # ۱) جعبه‌ی مفهوم بعد از \payvand{}{} و پیش از \begin{masir}
    if '\\begin{mafhoom}' in block:
        raise ValueError('block already enriched')
    pv = end_of_macro_call(block, 'payvand', nargs=2)
    if pv is None:
        raise ValueError('no \\payvand found')
    # تا انتهای خط برو
    nl = block.find('\n', pv)
    nl = pv if nl == -1 else nl + 1
    block = block[:nl] + build_mafhoom(d) + block[nl:]

    # ۲) جعبه‌ی راهنمای اجرا بعد از \end{dastgah}
    key = '\\end{dastgah}'
    k = block.find(key)
    if k == -1:
        raise ValueError('no dastgah box found')
    k += len(key)
    nl = block.find('\n', k)
    nl = k if nl == -1 else nl + 1
    block = block[:nl] + build_tadris(d) + block[nl:]

    # ۳) \pol بعد از \nokte{}
    nk = end_of_macro_call(block, 'nokte', nargs=1)
    if nk is None:
        raise ValueError('no \\nokte found')
    nl = block.find('\n', nk)
    nl = nk if nl == -1 else nl + 1
    block = block[:nl] + '\\pol{%s}\n' % esc_tex(d['pol']) + block[nl:]
    return block


def run(grade, data):
    src = os.path.join(ROOT, '_v5_body%d.tex' % grade)
    orig = src + '.orig'
    if not os.path.exists(orig):
        io.open(orig, 'w', encoding='utf-8').write(
            io.open(src, encoding='utf-8').read())
    s = io.open(orig, encoding='utf-8').read()

    done, missing = 0, []
    for n in range(1, 33):
        pat = r'\\begin\{jalase\}\{' + fa(n) + r'\}.*?\\end\{jalase\}'
        m = re.search(pat, s, re.S)
        if not m:
            missing.append(('block', n))
            continue
        if n not in data:
            missing.append(('data', n))
            continue
        new = enrich_block(m.group(0), data[n])
        s = s[:m.start()] + new + s[m.end():]
        done += 1
    io.open(src, 'w', encoding='utf-8').write(s)
    return done, missing


if __name__ == '__main__':
    import importlib
    # python3 inject.py            → پایه‌های ۵ و ۶ (رفتار پیشین)
    # python3 inject.py 1 2 3 4    → هر پایه‌ای که نام ببرید
    grades = [int(a) for a in sys.argv[1:]] or [5, 6]
    total = 0
    for grade in grades:
        mod = importlib.import_module('g%d' % grade)
        done, missing = run(grade, mod.E)
        total += done
        print('paye%d: enriched %d/32 sessions' % (grade, done))
        for kind, n in missing:
            print('   MISSING %s for session %d' % (kind, n))
    print('total %d sessions enriched' % total)
