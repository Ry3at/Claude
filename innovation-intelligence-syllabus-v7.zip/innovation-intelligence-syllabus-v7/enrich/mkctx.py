# -*- coding: utf-8 -*-
"""ساخت فایل‌های بافتار برای نویسندگان لایه‌ی راهنمای تدریس، پایه‌های ۱ تا ۴."""
import io, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from assemble_v5 import split_sessions

# پایه‌های ۱ و ۳ جلسه‌ی ۱ را به‌عنوان مرجع دارند، پس از جلسه‌ی ۲ شروع می‌شوند.
CHUNKS = {
    1: [('a', 2, 8), ('b', 9, 16), ('c', 17, 24), ('d', 25, 32)],
    2: [('a', 1, 8), ('b', 9, 16), ('c', 17, 24), ('d', 25, 32)],
    3: [('a', 2, 8), ('b', 9, 16), ('c', 17, 24), ('d', 25, 32)],
    4: [('a', 1, 8), ('b', 9, 16), ('c', 17, 24), ('d', 25, 32)],
}
BAND = {1: 'الف', 2: 'الف', 3: 'ب', 4: 'ب'}

os.makedirs(os.path.join(HERE, 'ctx'), exist_ok=True)
for g, chunks in CHUNKS.items():
    sess = split_sessions(
        io.open(os.path.join(ROOT, '_v5_body%d.tex' % g), encoding='utf-8').read())
    assert len(sess) == 32, (g, len(sess))
    for tag, lo, hi in chunks:
        nums = list(range(lo, hi + 1))
        out = [u'بلوک‌های سیلابس پایه‌ی %d (مقطع %s) — جلسات %s'
               % (g, BAND[g], ', '.join(str(n) for n in nums)),
               u'برای هر جلسه، هفت فیلد راهنمای تدریس بنویس.', '', '']
        for n in nums:
            out.append('=' * 60)
            out.append(u'### جلسه %d' % n)
            out.append(sess[n - 1].rstrip())
            out.append('')
        p = os.path.join(HERE, 'ctx', 'g%d_%s.txt' % (g, tag))
        io.open(p, 'w', encoding='utf-8').write('\n'.join(out))
        print('wrote', os.path.basename(p), len(nums), 'sessions')
