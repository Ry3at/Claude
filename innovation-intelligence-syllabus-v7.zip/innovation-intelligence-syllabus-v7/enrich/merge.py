# -*- coding: utf-8 -*-
"""ادغام چهار پاره‌ی هر پایه در یک فایل ۳۲ جلسه‌ای، به‌همراه جلسه‌ی مرجع."""
import importlib.util, io, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))

REF = {1: 'G1_S1', 3: 'G3_S1'}   # جلسه‌ی ۱ این دو پایه را خودم نوشته‌ام


def load(path, name='E'):
    spec = importlib.util.spec_from_file_location('m_' + os.path.basename(path)[:-3], path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return getattr(m, name)


def fmt(v, ind):
    pad = ' ' * ind
    if isinstance(v, str):
        return 'u%r' % v
    if isinstance(v, tuple):
        return '(' + ', '.join('u%r' % x for x in v) + ')'
    if isinstance(v, list):
        items = ['(u%r, u%r)' % (a, b) for a, b in v]
        return '[\n' + ''.join(pad + '    ' + it + ',\n' for it in items) + pad + ']'
    raise TypeError(v)


refmod = None
for g in (1, 2, 3, 4):
    E = {}
    if g in REF:
        if refmod is None:
            refmod = load(os.path.join(HERE, 'ref_examples_ab.py'), REF[g])
        E[1] = load(os.path.join(HERE, 'ref_examples_ab.py'), REF[g])
    for tag in ('a', 'b', 'c', 'd'):
        part = load(os.path.join(HERE, 'parts', 'g%d_%s.py' % (g, tag)))
        for k, v in part.items():
            assert k not in E, (g, tag, k)
            E[k] = v
    assert sorted(E) == list(range(1, 33)), (g, sorted(E))

    out = ['# -*- coding: utf-8 -*-',
           u'"""لایه‌ی راهنمای تدریس پایه‌ی %d — ۳۲ جلسه (ادغام‌شده، دست‌نویس نزنید)."""' % g,
           '', 'E = {']
    for n in range(1, 33):
        d = E[n]
        out.append('    %d: dict(' % n)
        for k in ('mafhoom', 'chera', 'khata', 'tafavot', 'meyar', 'poshtiban', 'pol'):
            out.append('        %s=%s,' % (k, fmt(d[k], 8)))
        out.append('    ),')
    out.append('}')
    p = os.path.join(HERE, 'g%d.py' % g)
    io.open(p, 'w', encoding='utf-8').write('\n'.join(out) + '\n')
    print('merged g%d.py — %d sessions' % (g, len(E)))
