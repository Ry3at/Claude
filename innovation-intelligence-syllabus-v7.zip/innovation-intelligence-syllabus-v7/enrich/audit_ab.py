# -*- coding: utf-8 -*-
"""ممیزی خودکار لایه‌ی راهنمای تدریس پایه‌های ۱ تا ۴."""
import importlib.util, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
KEYS = ('mafhoom', 'chera', 'khata', 'tafavot', 'meyar', 'poshtiban', 'pol')

# مرز واژه لازم است، وگرنه «تیم» داخل «هستیم» و «نیستیم» می‌افتد
BAN = [(u'گروه', re.compile(u'(?:^|[\\s‌«])گروه')),
       (u'سرگروه', re.compile(u'سرگروه')),
       (u'هم‌گروهی', re.compile(u'هم‌گروهی')),
       (u'هم‌تیمی', re.compile(u'هم‌تیمی')),
       (u'تیم', re.compile(u'(?:^|[\\s‌«])تیم(?:[\\s‌»،.]|$)')),
       (u'پارسال', re.compile(u'پارسال')),
       (u'سال گذشته', re.compile(u'سال گذشته'))]


def load(g):
    p = os.path.join(HERE, 'g%d.py' % g)
    spec = importlib.util.spec_from_file_location('g%d' % g, p)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m.E


def strings(d):
    out = []
    for k in KEYS:
        v = d[k]
        if isinstance(v, str):
            out.append((k, v))
        else:
            for it in v:
                if isinstance(it, str):
                    out.append((k, it))
                else:
                    out += [(k, x) for x in it]
    return out


def sents(t):
    return [s.strip() for s in re.split(u'[.؟!؛]', t) if len(s.strip().split()) >= 6]


bad = 0
allsent = {}
for g in (1, 2, 3, 4):
    E = load(g)
    probs = []
    for n in range(1, 33):
        for k, v in strings(E[n]):
            for name, rx in BAN:
                if rx.search(v):
                    probs.append(u'س%d/%s: واژه‌ی ممنوع «%s»' % (n, k, name))
        # مقطع الف: معیار نباید نوشتنی باشد
        if g == 1 and re.search(u'بنویسد|نوشته باشد|بنویسند', E[n]['meyar']):
            probs.append(u'س%d: meyar نوشتنی است (مقطع الف)' % n)
        for s in sents(' '.join(v for _, v in strings(E[n]))):
            allsent.setdefault(s, []).append((g, n))
    if E[32]['pol'] and re.search(u'جلسه‌ی بعد|جلسه‌ی ۳۳', E[32]['pol']):
        probs.append(u'س۳۲: pol به جلسه‌ی بعد اشاره دارد')
    print(u'پایه %d: %s' % (g, u'سالم' if not probs else u'%d مورد' % len(probs)))
    for p in probs:
        print('   ' + p)
    bad += len(probs)

dups = {s: v for s, v in allsent.items() if len(v) > 1}
print(u'\nجمله‌های تکراری میان جلسه‌ها: %d' % len(dups))
for s, v in list(dups.items())[:10]:
    print(u'   %s → %s' % (s[:70], v))
sys.exit(1 if (bad or dups) else 0)
