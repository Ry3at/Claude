# -*- coding: utf-8 -*-
"""بررسی یک فایل داده‌ی غنی‌سازی: python3 check_enrich.py g5.py"""
import importlib.util, os, re, sys

KEYS = ('mafhoom', 'chera', 'khata', 'tafavot', 'meyar', 'poshtiban', 'pol')
PERSIAN = re.compile(u'[؀-ۿ]')
LATIN_DIGIT = re.compile(u'[0-9]')
ZWNJ_TRAPS = [re.compile(u'(?:^|\\s)(?:می|نمی)\\s'),
              re.compile(u'\\s(?:ها|های|هایی|تر|ترین)(?:\\s|$)')]
FORBIDDEN = [(u'پارسال', u'ارجاع به پایه‌ی قبل'),
             (u'سال گذشته یاد', u'ارجاع به پایه‌ی قبل'),
             (u'نرم‌افزار هوشمند کلاس', u'جای‌نگهدار قدیمی')]
# موادی که بیرون از فهرست مجازند — با مرز واژه، وگرنه «الگو» شامل «لگو»
# و «برچسب» شامل «چسب» می‌شود و هشدار کاذب می‌دهد.
BAD_MATERIAL = [re.compile(u'(?:^|\\s)' + w + u'(?:\\s|$|\u200c)')
                for w in (u'چسب', u'قیچی', u'مقوا', u'لگو', u'چاپگر',
                          u'برد الکترونیکی', u'ربات واقعی')]


def load(path):
    spec = importlib.util.spec_from_file_location('m', path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m.E


def strings(d):
    out = []
    for k in KEYS:
        v = d.get(k)
        if isinstance(v, str):
            out.append((k, v))
        elif isinstance(v, (list, tuple)):
            for it in v:
                if isinstance(it, str):
                    out.append((k, it))
                elif isinstance(it, (list, tuple)):
                    for x in it:
                        out.append((k, x))
    return out


def check(path, lo=1, hi=32):
    E = load(path)
    errs, warns = [], []

    extra = [n for n in E if not (lo <= n <= hi)]
    if extra:
        errs.append('sessions outside the requested range: %s' % sorted(extra))

    for n in range(lo, hi + 1):
        if n not in E:
            errs.append('session %d missing' % n)
            continue
        d = E[n]
        for k in KEYS:
            if k not in d or not d[k]:
                errs.append('s%d: field %r missing or empty' % (n, k))

        if isinstance(d.get('khata'), (list, tuple)):
            if not (2 <= len(d['khata']) <= 3):
                errs.append('s%d: khata needs 2-3 items, got %d'
                            % (n, len(d['khata'])))
            for i, it in enumerate(d['khata'], 1):
                if not isinstance(it, (list, tuple)) or len(it) != 2:
                    errs.append('s%d: khata[%d] must be a 2-tuple' % (n, i))
                elif not it[0] or not it[1]:
                    errs.append('s%d: khata[%d] has an empty half' % (n, i))
        if isinstance(d.get('tafavot'), (list, tuple)):
            if len(d['tafavot']) != 2:
                errs.append('s%d: tafavot must be a 2-tuple' % n)

        # طول
        mf = d.get('mafhoom') or ''
        if len(mf.split()) > 95:
            warns.append('s%d: mafhoom %d words (>90)' % (n, len(mf.split())))
        if len(mf.split()) < 25:
            warns.append('s%d: mafhoom only %d words — likely too thin'
                         % (n, len(mf.split())))
        for k in ('chera', 'meyar', 'poshtiban', 'pol'):
            v = d.get(k) or ''
            if len(v.split()) > 40:
                warns.append('s%d: %s %d words (>35)' % (n, k, len(v.split())))

        # متن
        for k, v in strings(d):
            if PERSIAN.search(v) and LATIN_DIGIT.search(v):
                warns.append('s%d/%s: latin digit: %s' % (n, k, v[:50]))
            for rx in ZWNJ_TRAPS:
                mm = rx.search(v)
                if mm:
                    warns.append('s%d/%s: possible missing ZWNJ (%s): %s'
                                 % (n, k, mm.group(0).strip(), v[:50]))
                    break
            for frag, why in FORBIDDEN:
                if frag in v:
                    errs.append('s%d/%s: forbidden (%s)' % (n, k, why))
            for rx in BAD_MATERIAL:
                mm = rx.search(v)
                if mm:
                    warns.append('s%d/%s: material outside whitelist? %r'
                                 % (n, k, mm.group(0).strip()))
            # آکولاد نامتوازن، که لاتک را می‌شکند
            if v.count('{') != v.count('}'):
                errs.append('s%d/%s: unbalanced braces' % (n, k))

    # جلسه‌ی ۳۲ پل به جلسه‌ی بعد ندارد
    if hi >= 32 and 32 in E and E[32].get('pol'):
        p = E[32]['pol']
        if u'جلسه‌ی بعد' in p or u'جلسه‌ی ۳۳' in p:
            warns.append('s32: pol should close the year, not point to a next session')

    return E, errs, warns


if __name__ == '__main__':
    # python3 check_enrich.py g1.py            → جلسات ۱ تا ۳۲
    # python3 check_enrich.py parts/g1_a.py 2 8 → فقط همان بازه
    p = sys.argv[1]
    lo = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    hi = int(sys.argv[3]) if len(sys.argv) > 3 else 32
    E, errs, warns = check(p, lo, hi)
    print('%s — %d sessions (range %d..%d)' % (os.path.basename(p), len(E), lo, hi))
    for w in warns:
        print('WARN  ' + w)
    for e in errs:
        print('ERROR ' + e)
    print('OK' if not errs else 'FAILED (%d errors)' % len(errs))
    sys.exit(1 if errs else 0)
