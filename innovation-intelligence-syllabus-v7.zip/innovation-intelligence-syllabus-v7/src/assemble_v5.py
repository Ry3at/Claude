# -*- coding: utf-8 -*-
"""سرهم‌کردن شش فایل نسخه‌ی ۵: پیش‌درآمد + مقدمه + فصل‌ها و جلسات + پیوست‌ها."""
import io, os, re, sys

# مسیرها نسبت به خودِ این فایل‌اند، نه به پوشه‌ی کاری — تا بسته هرجا باز شد کار کند.
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import mkfront
from frontdata import GNAME, CHAPTERS

FA = '۰۱۲۳۴۵۶۷۸۹'
PRE = io.open(os.path.join(HERE, '_preamble.tex'), encoding='utf-8').read()


def split_sessions(body):
    idx = [m.start() for m in re.finditer(r'\\begin\{jalase\}', body)]
    idx.append(len(body))
    return [body[idx[i]:idx[i + 1]].rstrip() + '\n' for i in range(len(idx) - 1)]


def build(g):
    pre = PRE.replace('پایه‌ی اول ابتدایی', 'پایه‌ی %s ابتدایی' % GNAME[g])
    body = io.open(os.path.join(HERE, '_v5_body%d.tex' % g), encoding='utf-8').read()
    sess = split_sessions(body)
    assert len(sess) == 32, (g, len(sess))

    out = [pre, mkfront.build(g)]
    for ci, (cname, crange, cblurb) in enumerate(CHAPTERS[g]):
        out.append('\n%% =====================================================================\n')
        out.append('\\section{فصل %s — %s (جلسات %s)}\n\n' %
                   (['یکم', 'دوم', 'سوم', 'چهارم'][ci], cname, crange))
        out.append('\\begin{fasl}{هدف فصل}\n%s\n\\end{fasl}\n\n' % cblurb)
        for s in sess[ci * 8:(ci + 1) * 8]:
            out.append(s + '\n')
    out.append('\n%% =====================================================================\n')
    out.append(mkfront.appendix(g))
    out.append('\\end{document}\n')

    path = os.path.join(HERE, 'paye%d.tex' % g)
    io.open(path, 'w', encoding='utf-8').write(''.join(out))
    return path


if __name__ == '__main__':
    for g in range(1, 7):
        print('built', build(g))
