# -*- coding: utf-8 -*-
"""بررسی نهایی هر شش فایل نسخه‌ی ۵."""
import io, re
FA = '۰۱۲۳۴۵۶۷۸۹'

# لایه‌ی راهنمای تدریس (نسخه‌ی ۶) نثر توضیحیِ معلم است، نه دستور فعالیت.
# ممنوعیت واژگانی برای فعالیت دانش‌آموز وضع شده؛ بدون کنارگذاشتن این لایه،
# «گروهی از مردم» و «بلوک کد» هشدار کاذب می‌دهند.
_TEACHER_LAYER = [
    re.compile(r'\\begin\{mafhoom\}.*?\\end\{mafhoom\}', re.S),
    re.compile(r'\\begin\{tadris\}.*?\\end\{tadris\}', re.S),
    re.compile(r'\\pol\{(?:[^{}]|\{[^{}]*\})*\}', re.S),
]


def strip_teacher_layer(t):
    for rx in _TEACHER_LAYER:
        t = rx.sub(' ', t)
    return t
def num(s):
    d = ''.join(str(FA.index(c)) for c in s if c in FA)
    return int(d) if d else None


# ---------- بررسی پیوست‌ها ----------
# دو خرابی واقعی که پیش‌تر بی‌صدا از آزمون رد می‌شد:
#   ۱) جدول «شش شاخص رشد» با ردیف‌های خالی چاپ می‌شد.
#   ۲) حرف پیوست‌ها نه پشت‌سرهم بود و نه به ترتیب الفبا.
import mkfront
import mkreport

_LETTERS = ['الف', 'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ', 'د']


def check_appendix(g, s):
    out = []
    i = s.find('\\section{پیوست‌ها}')
    if i < 0:
        return ['بخش پیوست‌ها پیدا نشد']
    apx = s[i:]

    got = re.findall(r'\\subsection\*\{پیوست (\S+) —', apx)
    want = _LETTERS[:len(got)]
    if got != want:
        out.append('ترتیب حروف: %s (انتظار %s)' % (' '.join(got), ' '.join(want)))
    if len(got) != (6 if g in (5, 6) else 4):
        out.append('شمار پیوست‌ها %d است' % len(got))

    for name, _ in mkreport.SHAKHES[mkfront.BAND[g]]:
        if apx.count(name) < 1:
            out.append('شاخص «%s» در فرم گزارش نیست' % name)
    return out


# ---------- بررسی خروجی پی‌دی‌اف ----------
# جعبه‌های شکست‌پذیرِ تودرتو می‌توانند پشته‌ی رنگِ درایور را نامتوازن بگذارند؛
# آن‌وقت متن در پی‌دی‌اف هست ولی سفید روی سفید چاپ می‌شود و صفحه خالی
# به نظر می‌رسد — بدون هیچ خطایی در لاگ. این بررسی، نسبت جوهر به نویسه را
# برای هر صفحه می‌سنجد؛ صفحه‌ی سالم بسیار بالاتر از آستانه است.
def check_pdf(g, thresh=10.0):
    import os
    import subprocess
    pdf = 'paye%d.pdf' % g
    if not os.path.exists(pdf):
        return ['%s ساخته نشده' % pdf]
    try:
        import numpy as np
        from PIL import Image
    except ImportError:
        return []

    info = subprocess.run(['pdfinfo', pdf], capture_output=True, text=True).stdout
    n = int(info.split('Pages:')[1].split()[0])
    bad = []
    for p in range(1, n + 1):
        txt = subprocess.run(['pdftotext', '-f', str(p), '-l', str(p), pdf, '-'],
                             capture_output=True, text=True).stdout
        # نقطه‌چین فرم‌ها ده‌ها نویسه است با جوهر ناچیز؛ شمردنشان صفحه‌های
        # سالمِ فرم را بی‌جهت مشکوک نشان می‌داد.
        chars = len([c for c in ''.join(txt.split()) if c not in '.…'])
        if chars <= 200:
            continue
        tmp = '/tmp/_vfy_%d' % g
        subprocess.run(['pdftocairo', '-f', str(p), '-l', str(p), '-r', '60',
                        '-gray', '-png', '-singlefile', pdf, tmp],
                       capture_output=True)
        ink = int((np.asarray(Image.open(tmp + '.png')) < 200).sum())
        if ink / chars < thresh:
            bad.append('ص%d (جوهر/نویسه %.1f)' % (p, ink / chars))
    return bad

# «هم‌تیمی» قاعده‌ی «فقط تنها یا دونفره» را می‌شکند و تا نسخه‌ی ۶ از این فهرست
# جا مانده بود، پس ۳۹ بار در پایه‌های ۱ تا ۴ و ۶ باقی ماند. واژه‌ی تنهای «تیم»
# را نمی‌شود اینجا گذاشت: زیررشته‌ی «هستیم» و «نیستیم» است — همان کلاس اشتباهی
# که پیش‌تر «لگو» داخل «الگو» ساخت.
BAD_WORDS = ['گروه', 'هم‌گروهی', 'سرگروه', 'هم‌تیمی',
             'مقوا', 'پوستر', 'قیچی', 'کارت چاپی', 'برگه‌ی چاپی',
             'اسکرچ', 'محیط برنامه‌نویسی', 'بلوکی',
             'پارسال', 'سال گذشته', 'پایه‌های پیش', 'پایه‌ی پیش',
             'پرونده‌ی شش‌ساله', 'دوساله', 'بیست شغل', '۲۰ شغل',
             'ربات اسباب‌بازی', 'شبیه‌ساز سخت‌افزاری', 'شبیه‌ساز رباتیک', 'حسگر واقعی',
             'دایره‌المعارف', 'شبکه‌ی زمینی', 'مونتاژ', 'تدوین ویدئو']
# واژه‌هایی که حضورشان فقط داخل بدنه‌ی جلسات ممنوع است، نه در مقدمه‌ی توضیحی
BODY_ONLY = set(['مقوا', 'پوستر', 'قیچی', 'بلوکی', 'اسکرچ', 'محیط برنامه‌نویسی',
                 'ربات اسباب‌بازی', 'شبیه‌ساز سخت‌افزاری', 'شبیه‌ساز رباتیک', 'حسگر واقعی', 'شبکه‌ی زمینی',
                 'مونتاژ', 'تدوین ویدئو', 'کارت چاپی', 'برگه‌ی چاپی', 'دایره‌المعارف'])

MAVAD_TOKENS = ['کاغذ', 'مداد', 'مدادرنگی', 'تبلت شخصی', 'هدفون', 'میکروفون',
                'نمایشگر کلاسی', 'چاپگر', '\\software']

ok = True
for g in range(1, 7):
    s = io.open('paye%d.tex' % g, encoding='utf-8').read()
    body = s[s.index('\\section{فصل یکم'):s.index('\\section{پیوست‌ها')]
    sess = re.findall(r'\\begin\{jalase\}\{([^}]*)\}\{([^}]*)\}(.*?)\\end\{jalase\}', body, re.S)
    bad = []

    for n, title, b in sess:
        blocks = re.findall(r'\\begin\{(amoozesh|taamol|arzyabi)\}\{([^}]*)\}', b)
        if len(blocks) != 3:
            bad.append((n, 'blocks=%d' % len(blocks))); continue
        if sum(num(x[1]) for x in blocks) != 60:
            bad.append((n, 'total!=60'))
        for env, hdr in blocks:
            seg = re.search(r'\\begin\{' + env + r'\}\{[^}]*\}(.*?)\\end\{' + env + r'\}', b, re.S).group(1)
            if sum(num(x) for x in re.findall(r'\\gam\{([^}]*)\}', seg)) != num(hdr):
                bad.append((n, env))
        for need in ['\\mamooriat{', '\\payvand{', '\\abzar{', '\\begin{dastgah}',
                     '\\khorooji{', '\\nokte{', '\\dtam{']:
            if need not in b:
                bad.append((n, 'missing ' + need))
        if 'سطح ۱' not in b or 'سطح ۳' not in b:
            bad.append((n, 'dtam not 3-level'))
        # مواد فقط از فهرست مجاز
        m = re.search(r'\\mavad\{(.*?)\}\n', b, re.S)
        if m:
            for tok in re.split(r'[،,]', m.group(1)):
                tok = tok.strip()
                if tok and not any(t in tok for t in MAVAD_TOKENS):
                    bad.append((n, 'mavad: ' + tok[:30]))

    # واژگان ممنوع در بدنه
    scan = strip_teacher_layer(body)
    for w in BAD_WORDS:
        for mm in re.finditer(re.escape(w), scan):
            line = scan[max(0, mm.start() - 60):mm.start() + 60].replace('\n', ' ')
            bad.append(('—', 'word «%s»: …%s…' % (w, line[:90])))
            break

    career = len(re.findall(r'\\shoghl\{', s))
    karneh = len(re.findall(r'\\begin\{karneh\}', s))
    print('paye%d: sessions=%d mamooriat=%d abzar=%d dastgah=%d shoghl=%d karneh=%d' % (
        g, len(sess), s.count('\\mamooriat{'), s.count('\\abzar{'),
        s.count('\\begin{dastgah}'), career, karneh))
    need_secs = ['\\software{} چه می‌تواند بکند',
                 'کلاس یک‌به‌یک — دستگاه شخصی، تنها یا دونفره',
                 'مأموریت‌ها، نشان‌ها و سطح‌ها',
                 'جعبه‌ابزار هوش مصنوعی',
                 'پیوند با برنامه‌ی درسی — محور موضوعی',
                 'گزارش دوره‌ای عملکرد به خانواده',
                 'پیوست الف — فهرست کامل مواد']
    if g in (5, 6):
        need_secs.append('مسیر کارنما — آشنایی با ۱۰ شغل')
    miss = [x for x in need_secs if x not in s]
    print('   missing sections:', miss if miss else 'none')
    print('   problems:', bad[:6] if bad else 'none', '(%d total)' % len(bad) if bad else '')

    apx = check_appendix(g, s)
    pdfbad = check_pdf(g)
    print('   appendix:', apx if apx else 'ok')
    print('   blank-rendering pages:', pdfbad if pdfbad else 'none')

    if bad or miss or apx or pdfbad or len(sess) != 32:
        ok = False

print('ALL OK' if ok else 'ISSUES')
